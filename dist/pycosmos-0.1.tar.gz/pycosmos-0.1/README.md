# PyCosmos

This is the python package which serves as a judging client library for Cosmos front-ends.

##### To be used for Cosmos front-ends only.